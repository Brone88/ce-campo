# Digital Mop — reference UX/UI per Grocco

Esportazione del 14 ottobre 2026, versione pubblicata 10.
Sorgente UI: commit 438a5e48ad78511be7e4a6732e3e3a7f69eda2b7.
Demo: https://digital-mop-mockup.agilepika16.chatgpt.site

Questo README sostituisce le note incrementali delle versioni precedenti. Descrive lo stato attuale del mockup e gli accorgimenti per sviluppare l'app. Non contiene né sostituisce i piani integrali originari: i loro file non sono inclusi in questo ZIP.

## Avvio

Non servono npm, build o librerie. Dalla cartella estratta eseguire, con Python installato:

```sh
python -m http.server 8080 --directory dist
```

Aprire http://localhost:8080/#home. Si può aprire index.html direttamente per consultare il layout, ma localhost è preferibile per storage e funzionalità browser. Geolocalizzazione su dispositivo richiede un contesto sicuro e autorizzazione. Il catalogo è dimostrativo, in zona Roma: cercare da altre città può non restituire campi.

## Perimetro e priorità

Mockup statico HTML/CSS/JavaScript, mobile first, per una futura PWA rivolta indicativamente a utenti 20–40 anni. La prenotazione è l'azione centrale: form subito in home dopo l'autenticazione. Il resto deve essere di contorno.

Priorità: nuova prenotazione e aggiornamenti della richiesta in corso; storico; account, fatturazione e impostazioni. Navigazione principale: **Prenota / Storico / Account**. “Attuale” non è una voce del menu: si raggiunge dall'alert di aggiornamento o dalla richiesta nello storico. Lo storico presenta in cima l'eventuale richiesta in corso.

Il mockup non implementa backend, autenticazione reale, pagamenti, telefonate, messaggi, installazione PWA, service worker o offline. Non contatta strutture e non prenota realmente. La reportistica non ha UI in questo scope.

## Form di prenotazione

- Durata fissa: 90 minuti. Orario esatto; alternative richiedono nuova autorizzazione.
- Tipologia e ambiente filtrano subito la lista insieme a posizione, raggio, data e ora.
- **Outdoor / Indoor**: radio mutuamente esclusivi, Outdoor predefinito per un nuovo utente. L'ultima richiesta può ripristinare Indoor.
- “Dove ti trovi”: autocomplete di indirizzi reali e pulsante geolocalizzazione; nessun “Apri su Maps”. Coordinate selezionate necessarie per il filtro geografico.
- Senza ultima richiesta salvata, posizione e raggio partono dalle impostazioni account.
- Solo raggio massimo, con slider; nessun campo distanza minima.
- Lista con checkbox per includere/escludere ogni campo e frecce su/giù per modificarne l'ordine. Gli esclusi restano visibili e reincludibili. Se nessun campo è selezionato, invio disabilitato.
- Prezzo del singolo campo per 90 minuti separato dal costo del servizio.
- Riepilogo prima dell'invio; la richiesta acquisisce una copia dei criteri e dei campi ordinati. Modifiche successive non devono alterarla.

### Ultime scelte, senza preferiti nel profilo

La sezione campi preferiti è rimossa. La demo salva nel browser i dati dell'ultima **richiesta inviata**, non ogni modifica della bozza: tipologia, ambiente, ora, indirizzo/coordinate, raggio, ordine ed esclusioni. Al caricamento ripropone tali dati e una nuova data (domani, fuso Europe/Rome), da controllare prima dell'invio. Non riutilizza la vecchia data.

Ordine ed esclusioni si modificano sempre dalla lista nella ricerca. Nell'app reale il prefill dovrà essere associato all'utente autenticato, con validazione dei campi ancora esistenti/attivi. Non è una nuova lista di preferiti globale. Le scelte ripristinate devono restare modificabili e non causare invii automatici.

### Differenze da allineare nello sviluppo

Il catalogo e i controlli attuali mostrano 5/7/11; il requisito admin consolidato prevede anche calcio a 9. Integrare il 9 in modo coerente su catalogo, form, validazione e prefill. Non interpretare un vecchio riferimento a 8 come decisione approvata.

Lo slider implementato nella demo è 1–100 km; il piano precedente indicava 0–48 km. Questa esportazione conserva il codice pubblicato: allineare esplicitamente l'intervallo nel prodotto, senza dedurlo dal solo aspetto dello slider.

## Crediti e linguaggio

I crediti restano ben visibili, con progress bar e quota di crediti presi in prestito per eventuali penali di colore diverso. Questa quota non è spendibile per il lavoro dell'agente.

Mostrare nell'interfaccia saldo utile, azione e conseguenze concrete. Mettere tecnicismi e spiegazioni in icone info con testi brevi. La demo usa dialog contestuali su desktop e pannello dal basso su mobile, attivabili anche al tap e da tastiera; non affidarsi al solo hover. Mantenere chiusura, Escape e ritorno del focus.

Le condizioni essenziali restano visibili prima del consenso: prezzo del campo separato, garanzia richiesta, termine di disdetta gratuita ed eventuale penale. Non nasconderle tutte nei tooltip.

### Gestione dei consumi

- Nessun budget massimo per richiesta configurabile dall'utente.
- Una richiesta accettata viene gestita fino a un esito terminale: non significa garantire una prenotazione riuscita.
- La demo distingue lavoro effettivo, addebito utente ed eccedenza assorbita da Digital Mop. Il saldo non diventa negativo e il consumo operativo non intacca garanzia/prestito per penali.
- Esempio verificato: saldo 100, lavoro 125, addebito 100, quota piattaforma 25.
- A saldo zero non si avviano nuove richieste; quelle accettate continuano. La disdetta rimane accessibile.
- La demo impedisce una seconda nuova richiesta attiva simultanea. Soglie non nulle di ammissione, tariffe e stime vanno calibrate su misure reali; i valori dimostrativi non sono un listino.
- Il ledger del mockup è soltanto in memoria: produzione richiede idempotenza, concorrenza controllata, metering e ripresa durevole.

Le penali tutelano affidabilità e reputazione verso le strutture, non sono un risarcimento economico al gestore. I numeri della demo (ad esempio 20 crediti e 24 ore) sono esempi. Eventuali pagamenti/penali economiche del gestore restano distinti.

## Attesa, disponibilità e richieste in corso

Disponibilità sconosciuta significa “da verificare”, mai libera. Il calendario interno viene popolato da informazioni raccolte; non è sincronizzato con l'inventario delle strutture. Il filtro esclude osservazioni esplicite di occupazione sovrapposte ai 90 minuti.

Quando una struttura chiede tempo, l'agente concorda quando richiamare e l'utente decide se attendere o proseguire. Il blocco durante l'attesa riguarda solo Digital Mop, non i clienti diretti o il calendario del gestore. Le sceneggiature del mockup non costituiscono un orchestratore reale.

Nell'implementazione preservare le decisioni sulla concorrenza: se un candidato prioritario conferma mentre un altro tentativo non è concluso, confermare il prioritario e ritirare esplicitamente i tentativi abbandonati con le strutture.

## Account, verifica e contatti

Verifica telefono e identità SPID/CIE obbligatorie prima della prenotazione nel prodotto. Le schermate demo non sono un controllo di sicurezza. Google/passkey e integrazioni reali restano da implementare secondo il piano di autenticazione.

Il widget “Quando possiamo chiamarti” offre giorni singoli, scorciatoie feriali/weekend/tutti, preset e fino a due fasce non sovrapposte. Riepilogo in fuso italiano, controlli su giorni mancanti e intervalli invertiti/sovrapposti. Impostazioni salvate localmente. Associazioni Telegram/WhatsApp e fatturazione sono reference UI, non servizi attivi.

## Admin strutture e campi

Anagrafica struttura: nome, indirizzo, contatti, canale preferito e reperibilità per canale. Termine di preavviso per disdetta gratuita a livello struttura, applicato ai campi; non configurare qui un risarcimento economico Digital Mop.

Ogni campo ha nome, tipologia, **ambiente indoor/outdoor**, prezzo per 90 minuti e stato. Il controllo ambiente è presente sia nel wizard nuova struttura sia nell'aggiunta/modifica del campo, con Outdoor predefinito. Nel catalogo demo aggiunta e modifica aggiornano la ricerca nella sessione; richieste già inviate conservano i propri dati.

Wizard strutture, login/MFA, audit e calendario sono dimostrativi. Il wizard non persiste una nuova struttura in un database. Non usare le funzioni admin come API o modello di autorizzazione reale.

## Mappa dei sorgenti

| File | Responsabilità |
| --- | --- |
| dist/index.html | Shell e ordine di caricamento degli script |
| dist/style.css | Stili base e admin |
| dist/mobile.css | Home mobile, navigazione, CTA, crediti, info e radio |
| dist/app.js | Stato demo, viste base, azioni e admin |
| dist/mobile.js | Catalogo, ricerca, filtri, prefill, selezione/ordine e profilo |
| dist/field-settings.js | Radio ambiente condivisi e CRUD demo dei campi |
| dist/address.js | Autocomplete Photon, reverse lookup e geolocalizzazione |
| dist/credits.js | Stato e logica dimostrativa dei crediti |
| dist/completion-demo.js | Scenari di consumo e completamento delle richieste |
| dist/call-hours.js | Reperibilità utente |
| dist/info.js | Testi e interazioni delle icone info |

Gli script condividono globali e sovrascrivono alcune viste/azioni per successive evoluzioni del mockup: rispettare l'ordine di index.html per eseguirlo. Nello sviluppo reale separare componenti, stato e servizi; non trasferire automaticamente questa architettura dimostrativa nel prodotto.

Percorsi principali: #home, #storico, #profilo, #crediti, #canali, #posizione, #attuale, #registrazione, #verifica, #admin, #admin-nuova, #admin-dettaglio, #admin-calendario. Il vecchio #preferenze ora apre la prenotazione per compatibilità.

## Persistenza, servizi esterni e reset

Posizione account, reperibilità e ultima richiesta sono salvate in localStorage sullo stesso browser/origine. Saldo, scenari, richieste e modifiche admin sono principalmente in memoria e non costituiscono archiviazione affidabile. Cancellare i dati del sito per ripartire dai default.

L'autocomplete chiama realmente il servizio pubblico Photon (photon.komoot.io); richiede rete, disponibilità del servizio e invia le query di indirizzo. Reverse lookup invia le coordinate. Per produzione scegliere servizio, condizioni d'uso, capacità e gestione dei dati adeguati. Non ci sono chiavi API incluse. Verificare anche eventuali risorse font esterne dichiarate nell'HTML/CSS per uso offline.

## Verifiche e accorgimenti prima del porting

Sintassi JS e verifiche simulate in Node hanno coperto filtri, ordine/esclusioni, ambiente admin, copia immutabile delle richieste, ripristino delle ultime scelte con nuova data, contabilità demo e fasce di reperibilità. Non equivalgono a test end-to-end.

Verifica visiva nel browser e su dispositivi reali non disponibile nell'ultima sessione. Prima dello sviluppo verificare almeno: layout 320–430 px e safe area; tastiera virtuale con CTA fissa; focus e screen reader su radio/checkbox/dialog/autocomplete; geolocalizzazione consentita/negata; rete assente; lista vuota; tutti i campi esclusi; prefill dopo reload; ripristino Indoor; passaggio al giorno successivo nel fuso italiano.

Questo ZIP include soltanto sorgenti statici e README aggiornato. Esclude Git, configurazioni di hosting, credenziali e file di lavoro. È una reference grafica e funzionale per Grocco, non una consegna pronta per la produzione.
